import telebot
import asyncio
import csv
from telebot.async_telebot import AsyncTeleBot
from collections import defaultdict

# Replace 'YOUR_BOT_TOKEN' with your actual bot token
TOKEN = '7939741557:AAHGEDG8NVbVJCXp7vGXjjgKIfY_IIfNgXY'
bot = AsyncTeleBot(TOKEN)

# Store uploaded files information
user_files = defaultdict(dict)

# Load BIN database from bin.csv
def load_bin_data():
    bin_data = {}
    try:
        with open('bin.csv', 'r') as f:
            reader = csv.reader(f)
            for row in reader:
                bin_number = row[0]
                bin_data[bin_number] = {
                    "Brand": row[1],
                    "Card Type": row[2],
                    "Issuer": row[4],
                    "Country": row[8],
                    "Country Name": row[9]
                }
    except Exception as e:
        print(f"Error loading BIN data: {e}")
    return bin_data

# Load VBV database from vbv.txt
def load_vbv_data():
    vbv_data = {}
    try:
        with open('vbv.txt', 'r') as f:
            for line in f:
                parts = line.strip().split('|')
                vbv_data[parts[0]] = {
                    "Vbv Status": parts[1],
                    "Vbv Response": parts[2]
                }
    except Exception as e:
        print(f"Error loading VBV data: {e}")
    return vbv_data

bin_data = load_bin_data()
vbv_data = load_vbv_data()

# Format response based on BIN and VBV data
def format_response(bin_number):
    bin_info = bin_data.get(bin_number)
    vbv_info = vbv_data.get(bin_number)

    if not bin_info:
        return f"BIN {bin_number} not found in database."

    response = f"""[⌥] 𝐁𝐈𝐍 𝐥𝐨𝐨𝐤𝐮𝐩 𝐀𝐩𝐢
━━━━━━━━━━━━━━━━━
[⌬] 𝐁𝐈𝐍 ⇢ {bin_number}
[⌬] 𝐈𝐧𝐟𝐨 ⇢ {bin_info['Brand']}-{bin_info['Card Type']}-{bin_info['Issuer']}
[⌬] 𝐈𝐬𝐬𝐮𝐞𝐫 ⇢ {bin_info['Issuer']}
[⌬] 𝐂𝐨𝐮𝐧𝐭𝐫𝐲 ⇢ {bin_info['Country Name']}
━━━━━━━━━━━━━━━━━"""

    # If VBV data is found, include it. If not, return an error message for VBV data.
    if vbv_info:
        response += f"\nVbv Status: {vbv_info['Vbv Status']}\nVbv Response: {vbv_info['Vbv Response']}"
    else:
        response += "\nVbv Status: ERROR\nVbv Response: ERROR"

    return response

# Command to handle /start and /help
@bot.message_handler(commands=['start', 'help'])
async def send_welcome(message):
    await bot.reply_to(message, "Welcome! Send me a 6-digit BIN number or a text file containing multiple BIN numbers.")

# Command to check single BIN
@bot.message_handler(commands=['bin'])
async def check_single_bin(message):
    if message.reply_to_message and message.reply_to_message.document:
        await check_file_bins(message)
    else:
        bin_number = message.text.split()[1] if len(message.text.split()) > 1 else None
        if bin_number and len(bin_number) == 6 and bin_number.isdigit():
            response = format_response(bin_number)
            await bot.reply_to(message, response)
        else:
            await bot.reply_to(message, "Please provide a valid 6-digit BIN number or reply to a file with /bin.")

# Handle document uploads (BIN CSV or VBV TXT files)
@bot.message_handler(content_types=['document'])
async def handle_document(message):
    try:
        file_info = await bot.get_file(message.document.file_id)
        user_files[message.chat.id][message.message_id] = file_info
        await bot.reply_to(message, "File received. Reply to this message with /bin to start checking the BINs.")
    except Exception as e:
        await bot.reply_to(message, f"An error occurred while processing the file: {str(e)}")

# Command to check BINs from file
@bot.message_handler(func=lambda message: message.text == '/bin' and message.reply_to_message and message.reply_to_message.document)
async def check_file_bins(message):
    try:
        reply_to_message = message.reply_to_message
        file_info = user_files[message.chat.id].get(reply_to_message.message_id)
        
        if not file_info:
            await bot.reply_to(message, "Sorry, I couldn't find the file information. Please upload the file again.")
            return

        downloaded_file = await bot.download_file(file_info.file_path)
        bin_numbers = downloaded_file.decode('utf-8').splitlines()

        await bot.reply_to(message, f"Starting to check {len(bin_numbers)} BINs. This may take a while...")

        async def process_and_send(bin_number):
            if len(bin_number) == 6 and bin_number.isdigit():
                response = format_response(bin_number)
                await bot.send_message(message.chat.id, response)
            else:
                await bot.send_message(message.chat.id, f"Invalid BIN: {bin_number}")
        
        tasks = [asyncio.create_task(process_and_send(bin)) for bin in bin_numbers]
        await asyncio.gather(*tasks)

        await bot.send_message(message.chat.id, "Finished checking all BINs.")
        
        # Clean up the stored file information
        del user_files[message.chat.id][reply_to_message.message_id]
        
    except Exception as e:
        await bot.reply_to(message, f"An error occurred while checking the BINs: {str(e)}")

async def main():
    await bot.polling(non_stop=True, timeout=60)

if __name__ == '__main__':
    asyncio.run(main())
